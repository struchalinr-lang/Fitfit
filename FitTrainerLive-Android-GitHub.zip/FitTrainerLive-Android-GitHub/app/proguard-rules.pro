# Keep JS bridge methods for FitTrainer Live
-keepclassmembers class com.fittrainer.live.MainActivity$AndroidBridge {
    @android.webkit.JavascriptInterface <methods>;
}
